import paramiko
import sys

def connect_to_remote_host(sys_host,sys_user,sys_pwd,agentNM,agentPC,tLabel,parentNode):    
    host = sys_host
    print(host)
    username = sys_user
    #print(username)
    password = sys_pwd
    #print(password)
    agentName = agentNM.replace(':','-')               #need to change agent name to replace colon with dash
    productCode = agentPC.lower()                      #need to lowercase productCode
    filepath ='/opt/ibm/wlp/usr/servers/min/dropins/CentralConfigurationServer.war/data_source/'
    filename = 'private_situations.xml'
    sitiuation_Name = tLabel
    print(sitiuation_Name)
    parentNode = parentNode
    print(parentNode)

    if not all((agentName,productCode,filepath,filename,sitiuation_Name)):        
        print('Unable to set command due to missing value. Verify the following variables are not null: agentName,productCode,filepath,filename, and sitiuation_Name')
    elif not all((host,username,password)):
        print('Unable to establish connection due to missing server connection information. Verify the following variables are not null: host,username, and password')
    else:
        if parentNode:
            parentNode = parentNode.replace(':','-')
            command = 'grep ' + sitiuation_Name + ' ' + filepath + productCode + '/' + parentNode + '/' + filename
            print(command)
        else:
            command = 'grep ' + sitiuation_Name + ' ' + filepath + productCode + '/' + agentName + '/' + filename
            print(command)        
    
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect (host, username=username, password=password)    

        stdin, stdout, stderr = ssh.exec_command(command)
        #print('ssh successful.Closing connection')
        stdout = stdout.readlines()
        ssh.close()
        #print('Connection closed')
        #print(stdout)

        if not stdout:
            result = 'NO'
            print(result)
            print('No output returned for this command ' + command)
        else:
            for line in stdout:
                #print(line)
                output = line
                #print(output)
                if output.find(sitiuation_Name):
                    result = 'YES'
                    #print(result)
        results = {'command': command, 'stdout': stdout, 'result': result}             
        return results

