# delete existing report file if exist
import os

def remove_file(fileName):
    try:
        check_file_exists = os.path.isfile(fileName)
        if check_file_exists:
            os.remove(fileName)
        else:
            print('Warning: File not deleted.It does not exist ' +fileName)
    except IOError as e:
        print(e)
