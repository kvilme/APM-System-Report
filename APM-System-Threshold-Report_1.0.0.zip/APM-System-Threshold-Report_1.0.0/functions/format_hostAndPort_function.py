# get environment type and host, and format url for resource group and threshold
def format_host_port(envType,host,urlSub):
        try:
                #print('I am in try block')
                envType = envType.upper()
                print('envType: ' + envType)
                #print('hostToFormat:' + host)
                if envType and host is not None :
                        if envType == 'ON-PREMISE' :
                                rg_hostname = 'http://' + host + ':8090'
                                #print(rg_hostname)
                                t_hostname = 'https://' + host + ':8091'
                                #print(t_hostname)
                                return rg_hostname, t_hostname
                        if envType == 'SAAS' :
                                rg_hostname = 'https://' + host + urlSub
                                #print(rg_hostname)
                                return rg_hostname
                else:                        
                        if envType is None or envType != 'ON-PREMISE' or envType != 'SAAS':
                                print('Please set environment type <ON-PREMISE or SAAS> ')
                        elif host is None:
                                print('Please set host <hostFQDN or host_IP>')
        except Exception as e:
                 print(e)



