# generate base64 authorization header
import base64
def generate_b64_auth(uid,upwd,):
        try:
                ibmid = uid
                ibmid_pwd = upwd
                userAndPassword = (ibmid+':'+ibmid_pwd)
                encodeCred=base64.b64encode(bytes(userAndPassword,"utf-8"))
                auth = str(encodeCred,'utf-8')
                #print(auth)
                return auth
        except Exception as e:
                print(e)
