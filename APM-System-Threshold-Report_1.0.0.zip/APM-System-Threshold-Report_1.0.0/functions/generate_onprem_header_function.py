# create onPrem header	
def generate_onPrem_headers(auth):
        try:
                if auth is not None:
                        headers = {
                                'Content-type': 'application/json',
                                'Authorization': 'Basic ' +  auth,
                                }
                        return headers
                else:
                        print('Error: Cannot generate ON-PREMISE authentication header')
        except Exception as e:
                print(e)
