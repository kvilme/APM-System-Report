# create SaaS header
def generate_SaaS_headers(auth,cid,csecret,subgeo):
        try:
            headers = {
                'Content-type': 'application/json',
                'x-ibm-service-location': subgeo,
                'Authorization': 'Basic ' +  auth,
                'X-IBM-Client-Id': cid,
                'X-IBM-Client-Secret': csecret
                                }
            return headers                
  
        except Exception as e:
                print(e)
