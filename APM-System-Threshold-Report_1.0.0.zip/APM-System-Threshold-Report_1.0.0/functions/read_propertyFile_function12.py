# read and process user provided property input file 
import os
import sys
import json

class ReturnValue(object):
  def __init__(self,reportName,envType,host,uid,upwd,apm_version,cid,csecret,subgeo,urlSub,sys_user,sys_pwd,check_SitFile):
          self.reportName = reportName
          self.envType = envType
          self.host = host
          self.uid = uid
          self.upwd = upwd
          self.apm_version = apm_version
          self.cid = cid
          self.csecret = csecret
          self.subgeo = subgeo
          self.urlSub = urlSub
          self.sys_user = sys_user
          self.sys_pwd = sys_pwd
          self.check_SitFile = check_SitFile
          
     

def read_input_from_file(propFile):
        print('Property File: ' + propFile + '\n')
        env_data = {}
        try:
            check_file_exists =os.path.isfile(propFile)
            if check_file_exists:                    
                with open(propFile,'r') as myPropFile:
                    for line in myPropFile:
                        #li =line.strip()
                        if not line.startswith('#'):
                            line = line.strip()
                            line = line.replace('\t','')
                            line = line.replace(' ','')
                            line = line.split(':')
                            key = line[0]
                            value = line[1]
                            env_data[key] = value
                            #print(env_data)

                    reportName = env_data.get('reportName')
                    #print(reportName)
                    envType = env_data.get('envType')
                    #print(envType)
                    host = env_data.get('host')
                    #print(host)
                    uid = env_data.get('uid')
                    #print(uid)
                    upwd = env_data.get('upwd')
                    #print(upwd)
                    apm_version = env_data.get('apmVersion')
                    #print(apm_version)
                    cid = env_data.get('cid')
                    #print(cid)
                    csecret = env_data.get('csecret')
                    #print(csecret)
                    subgeo = env_data.get('subgeo')
                    #print(subgeo)
                    urlSub = env_data.get('saas_url_sub')
                    #print(urlSub)
                    sys_user = env_data.get('sys_user')
                    #print(sys_user)
                    sys_pwd = env_data.get('sys_pwd')
                    #print(sys_pwd)
                    check_SitFile = env_data.get('check_SitFile')
                    #print(check_SitFile)
                    return ReturnValue(reportName,envType,host,uid,upwd,apm_version,cid,csecret,subgeo,urlSub,sys_user,sys_pwd,check_SitFile)
                    #print(ReturnValue)                              
                    
            else:
                print('Error: Cannot find file ' + propFile) 
                
        except Exception as e:
            print(e)


#myInfo=read_input_from_file(sys.argv[1])


