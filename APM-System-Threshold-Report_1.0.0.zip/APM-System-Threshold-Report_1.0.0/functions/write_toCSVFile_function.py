# write data to csv file
import csv
import os

def write_data_to_csvfile(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name,rg_Id,In_SitFile):
        #print(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name,rg_Id,In_SitFile)
		
        reportFileName = reportFileName
        agentNM = agentNM
        agentST = agentST
        agentDM = agentDM
        agentDesc = agentDesc
        tLabel = tLabel
        t_Id = t_Id
        rg_Name = rg_Name
        rg_Id = rg_Id
        In_SitFile = In_SitFile
        
        header_data = ['AgentName','AgentStatus','AgentMonDomain','AgentDesc','Threshold','ThresholdID',
               'ResourceGroup','ResourceGroupID','In_Server_SitFile']
        #print(header_data)
        
        column_data = []
        column_data.append(agentNM)
        column_data.append(agentST)
        column_data.append(agentDM)
        column_data.append(agentDesc)
        column_data.append(tLabel)
        column_data.append(t_Id)
        column_data.append(rg_Name)
        column_data.append(rg_Id)
        column_data.append(In_SitFile)
        
        #print(column_data)      

		
        try:
            check_file_exists = os.path.isfile(reportFileName)
            with open(reportFileName, 'a+',newline='') as csvfile:
                writer = csv.writer(csvfile, delimiter=',',quoting =csv.QUOTE_NONE)
                if not check_file_exists:
                    writer.writerow(header_data)
                writer.writerow(column_data)

            csvfile.close()
        except Exception as e:
            print(e)



#write_data_to_csvfile('KVTestFile.csv','KVM3160:HJS494-KVM-T-3:V1','Offline','SAAS','Linux KVM Agent','VM_CPU_Pct_High_Crit','178','Linux KVM Agent','bcxbwA3s04lFu1UsMxr6Rg','Not_Check')
