import json
#import base64
#import csv
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
import time
import datetime
#import os
import sys
from functions.read_propertyFile_function12 import read_input_from_file
from functions.format_hostAndPort_function import  format_host_port
from functions.generate_base64Auth_header_function import  generate_b64_auth
from functions.generate_onprem_header_function import generate_onPrem_headers
from functions.generate_saas_header_function import  generate_SaaS_headers
from functions.delete_file_function import  remove_file
from functions.write_toCSVFile_function import write_data_to_csvfile
from functions.connect_to_remote_host_function import connect_to_remote_host



# disable https warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


# generating APM system report
myStartDateTime = datetime.datetime.now()
start_Time = time.time()
print('\n\n********************' + str(myStartDateTime) + ' Start Generating Report........********************\n\n')


def main():
    try:
        print(str(datetime.datetime.now()) + ' Processing environment properties file')
        envInfo = read_input_from_file(sys.argv[1])  
        #print('\n' + str(envInfo))
        auth = generate_b64_auth(envInfo.uid, envInfo.upwd)
        #print('\n' + str(auth))
        apm_version = envInfo.apm_version
        print('apm_version: ' + str(apm_version))
        #sys_user = envInfo.sys_user
        #print('\n' + str(sys_user))
        #sys_pwd = envInfo.sys_pwd
        #print('\n' + str(sys_pwd))
        check_SitFile = envInfo.check_SitFile
        print('check_SitFile: ' + str(check_SitFile))
        
        if envInfo.envType == 'ON-PREMISE':
            headers = generate_onPrem_headers(auth)
            #print('\n' + str(headers))
            myUrlHostInfo=format_host_port(envInfo.envType, envInfo.host, None)
            rg_hostname = myUrlHostInfo[0]
            print('\nrg_hostname: ' + str(rg_hostname))
            t_hostname = myUrlHostInfo[1]
            print('t_hostname: ' + str(t_hostname))
                       
        elif envInfo.envType == 'SAAS':
            headers = generate_SaaS_headers(auth,envInfo.cid,envInfo.csecret,envInfo.subgeo)
            #print('\n' + str(headers))
            rg_hostname=format_host_port(envInfo.envType, envInfo.host, envInfo.urlSub)
            print('\nrg_hostname: ' + str(rg_hostname))
            t_hostname=rg_hostname
            print('t_hostname: ' + str(rg_hostname))
  
        reportFileName = envInfo.reportName
        print('\nReport Name: ' + str(reportFileName))
        remove_file(reportFileName)
        
                    
                
            #==============================================================================#

        def get_resource_group(rg_hostname,headers):
            print('\n' + str(datetime.datetime.now()) + ' Getting list of resource groups')
            #print(rg_hostname)
            #print(headers)            
            #get custom and system resource group
              #print('Request_URL: ' + rg_hostname+'/1.0/topology/mgmt_artifacts?_filter=entityTypes:AgentGroup,AgentSystemGroup&_field=displayLabel')            
            r = requests.get(rg_hostname+'/1.0/topology/mgmt_artifacts?_filter=entityTypes:AgentGroup,AgentSystemGroup&_field=displayLabel',headers=headers,verify=False)
            if r.status_code != 200:
                print('Error: failed!\nStatus code: ' + str(r.status_code) + '\nResponse: ' + r.text + '\nExiting...')            
            else:
                grouplist = json.loads(r.text)
                #print(grouplist + '\n')                
                group_data = {}
                # iterate through the grouplist                       
                for group in grouplist['_items']:
                    rg_Id = group.get('_id', None)
                    rg_Name = group.get('displayLabel',None)                    
                    if rg_Name == 'All Resources':
                        continue
                    group_data[rg_Id] = {}
                    group_data[rg_Id].update({'groupId'   : rg_Id})
                    group_data[rg_Id].update({'groupName'   : rg_Name})
                    group_data[rg_Id].update({'thresholds'   : []})           
                return group_data
        resource_group_dict = get_resource_group(rg_hostname,headers)
        print('\n Resource_Group_List: ' + str(resource_group_dict) + '\n')
        

                    
        def get_assigned_threshold(t_hostname,headers,resource_group_dict):
           print(str(datetime.datetime.now()) + ' Getting list of thresholds assigned to resource group')
            #print('I AM IN THRESHOLD')
            #resource_assignment_dict ={}
            #print(resource_group_dict)
           for key,value in resource_group_dict.items():
                rg_Id = key
                #print('\n' + rg_Id)
                rg_Name = value['groupName']
                #print(rg_Name)                
                #get thresholds associated with each resource group
                  #print('Request_URL: ' + t_hostname+'/1.0/thresholdmgmt/resource_assignments?_filter=resource._id%3D'+rg_Id+'')
                r = requests.get(t_hostname+'/1.0/thresholdmgmt/resource_assignments?_filter=resource._id%3D'+rg_Id+'',headers=headers, verify=False)
                #print(r.status_code)
                if r.status_code == 200:
                    threshlist = json.loads(r.text)
                    #print(threshlist, '\n')
                    for threshold in threshlist['_items']:
                        t_Id = threshold.get('threshold').get('_id')
                        #print('rg_Id:' + str(rg_Id))
                        #print('t_Id:' + str(t_Id))   
                        #get threshold label
                         #print('Request_URL: ' + t_hostname+'/1.0/thresholdmgmt/threshold_types/itm_private_situation/thresholds/'+t_Id+'')
                        r = requests.get(t_hostname+'/1.0/thresholdmgmt/threshold_types/itm_private_situation/thresholds/'+t_Id+'',headers=headers, verify=False)                                
                        tIdList = json.loads(r.text)
                        #print(tIdList)
                        tLabel = tIdList.get('label',None)
                        tApToAgType = tIdList.get('_appliesToAgentType',None)
                        resource_group_dict[rg_Id]['thresholds'].append({'thresholdId' : t_Id,'thresholdName' : tLabel,'tAappliesToAgentType' : tApToAgType})
                    if not threshlist['_items']:
                        print('rg_Id: ' + str(rg_Id) + '\nrg_Name: ' + str(rg_Name) + '\nNo thresholds assigned\n')
           return resource_group_dict                            
            #print(resource_assignment_dict)
            #return resource_assignment_dict                              
        threshold_assignment_dict = get_assigned_threshold(t_hostname,headers,resource_group_dict)
        #print('\n Thresholds_Assigned_To_ResourceGroup: \n' + str(threshold_assignment_dict))
        
        
        def get_agents_assigned_resource_group(rg_hostname,headers,resource_group_dict,threshold_assignment_dict):
            print(str(datetime.datetime.now()) + ' Getting list of agents assigned to resource group.Verifying if threshols applicable for agent and In_SitFile')
            #print("I AM IN AGENT SECTION")
            #print(rg_hostname)
            check_SitFile_Responses = []
            agent_assignment_dict = {}
            #print(agent_assignment_dict)
            for groupId,groupValue in threshold_assignment_dict.items():
                #print(groupValue)
                rg_Id = groupId
                #print(rg_Id)
                rg_Name = groupValue['groupName']
                #print(rg_Name)
                threshold_List = groupValue['thresholds']
                print('\nThreshold_List_For_ResourceGroup: ' + str(rg_Name) + ' ' + str(rg_Id) + '\n' + str(threshold_List))                
                #get agents assigned to each custom or system resource group
                  #print(rg_hostname+'/1.0/topology/mgmt_artifacts/'+rg_Id+'/references/to/contains')
                r = requests.get(rg_hostname+'/1.0/topology/mgmt_artifacts/'+rg_Id+'/references/to/contains',headers=headers, verify=False)
                if r.status_code == 200:                
                    #print(r.status_code)
                    agentlist = json.loads(r.text)
                    print('\nAgents_Assigned_To_ResourceGroup: ' + str(rg_Name) + ' ' + str(rg_Id))                    
                    for agent in agentlist['_items']:
                        #try:
                        agentNM = agent.get('keyIndexName',None)
                        print(agentNM)
                        agentST = agent['online']                               
                        if agentST == 'Y':
                            agentST= 'Online'
                        elif agentST == 'N':
                            agentST = 'Offline'
                        elif agentST == 'D':
                            agentST = 'Deleted'
                        else:
                            agentST = 'Null'
                        print(agentST)
                        agentDM = agent.get('monitoringDomain',None)                      
                        agentDesc = agent.get('description',None)
                        agentPC = agent.get('productCode',None)
                        parentNode = agent.get('parentNode',None)                    
                        
                        # check if resource group has thresholds
                        In_SitFile = 'Not_Check'
                        if (len(threshold_List)) == 0:
                            tLabel = 'No threshold assigned to resource group'
                            t_Id = 'None'
                            write_data_to_csvfile(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name, rg_Id,In_SitFile)
                        else:                          
                            for i in range(len(threshold_List)):
                                t_Id = threshold_List[i]['thresholdId']
                                if t_Id == '':
                                    t_Id = 'None'
                                print(t_Id)
                                tApToAgType = threshold_List[i]['tAappliesToAgentType']
                                if tApToAgType == '':
                                    tApToAgType == 'None'
                                print(tApToAgType)
                                tLabel = threshold_List[i]['thresholdName']                                                           
                                if agentDM == 'ITM':
                                    tLabel = 'APM threholds are not distributed to ITM agents: ' + str(tLabel)
                                    write_data_to_csvfile(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name,rg_Id,In_SitFile)
                                if  tApToAgType != agentPC:
                                    tLabel = 'Not applicable for agent type ' + str(agentPC) + ':  ' +tLabel
                                    write_data_to_csvfile(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name,rg_Id,In_SitFile)
                                if (tApToAgType == agentPC and agentDM != 'ITM'):                                    
                                    if check_SitFile == 'Yes':
                                        print('\n' + str(datetime.datetime.now()) + ' Verifying if threshold exist in agent server private_situations.xml file')
                                        response = connect_to_remote_host(envInfo.host,envInfo.sys_user,envInfo.sys_pwd,agentNM,agentPC,tLabel,parentNode) 
                                        print('Threshold file check result: ' + str(response))
                                        In_SitFile = response.get('result')                                        
                                        #print('In_SitFile: ' + str(In_SitFile))
                                        check_SitFile_Responses.append(In_SitFile)    
                                    print('\n check_SitFile_Results: ' + str(check_SitFile_Responses))                                    
                                    write_data_to_csvfile(reportFileName,agentNM,agentST,agentDM,agentDesc,tLabel,t_Id,rg_Name,rg_Id,In_SitFile)
                elif r.status_code != 200:
                    print('rg_Id: ' + str(rg_Id) + '\nrg_Name: ' + str(rg_Name) + '\nNo agents assigned\n')                    
            return check_SitFile_Responses             
                                   
        check_SitFile_Results = get_agents_assigned_resource_group(rg_hostname,headers,resource_group_dict,threshold_assignment_dict)
        #print(check_SitFile_Results)
        # Verify if check_SitFile_Responses contains NO
        #check_SitFile_Results.append('NO')
        #print(check_SitFile_Results)
        if 'NO' in check_SitFile_Results:
            print('\n check_SitFile_Results contains NO response(s). Review csv report to determine why threshold(s) is not found in the  agent private_situations.xml file on the server')
                                             
    except Exception as e:
        print(e)

main()


stop_Time = time.time()
myEndDateTime = datetime.datetime.now()
print('\n\n********************' + str(myEndDateTime) + ' End Generating Report........********************\n\n')
total_Time = round(stop_Time - start_Time,6)
print('Total Execution Time: ' + str(total_Time)+ ' seconds')                                            
                                                    
 

